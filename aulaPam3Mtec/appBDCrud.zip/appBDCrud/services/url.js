{/* COLOQUE AQUI SEU ENDEREÇO IP */}
const url =  'http://10.68.36.112/';
export default url;