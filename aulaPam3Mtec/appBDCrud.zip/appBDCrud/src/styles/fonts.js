export default {
    heading: 'Jost_600SemiBold',
    text: 'Jost_400Regular',
    complement: 'Jost_400Regular'
  }